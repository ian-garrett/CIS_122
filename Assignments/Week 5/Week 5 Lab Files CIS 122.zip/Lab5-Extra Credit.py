# by Ian Garrett
# Lab5-Extra Credit

print ("Tiny National Bank of Walterville\nCredit Card Payments")

def get_minpay(balance):
    ''' float -> round.float -> string
takes balance and calculates the appropriate payment due.

Examples:
Credit card balance? 100
Minimum payment due: $10.0

Credit card balance? 501
Minimum payment due: $16.03'''
    # takes credit card balance and returns appropriate payment due
    if balance == 0:
        print ("Your balance is current, no payment is needed")
    elif 0 < balance <= 10:
        # changed minimum amount from $12 to $10
        print ("Minimum payment due:","$" + str(round(balance, 2)))
    elif 10 <= balance <= 100:
        # changed minimum amount from $12 to $10
        print ("Minimum payment due: $10.0")
    else:
        print ("Minimum payment due:", "$" + str(round((balance*.032), 2)))
        # changed .027 to .032
        
reset = 'y'
while reset == 'y':
    account_balance = float(input("\nCredit card balance? "))
    get_minpay(account_balance)
    reset = input("\nAnother customer (y or n)? ")

