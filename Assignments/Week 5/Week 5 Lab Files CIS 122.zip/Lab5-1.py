# by Ian Garrett
# Lab5-1

print ("Tiny National Bank of Walterville\nCredit Card Payments")

reset = 'y'
while reset == 'y':
    account_balance = round(float(input("\nCredit card balance? ")),2)
    # insert if/elsif statement for returning payment due
    reset = input("\nAnother customer (y or n)? ")

def get_minpay():
    # takes credit card balance and returns appropriate payment due
    print ("Payment due")

get_minpay()
