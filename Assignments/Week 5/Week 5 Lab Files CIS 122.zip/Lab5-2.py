# by Ian Garrett
# Lab5-2

# I got a little ahead of myself and put all the print statements in this
# as well as in 5-3. I hope this is not an issue, please let me know if it is

print ("Tiny National Bank of Walterville\nCredit Card Payments")

def get_minpay(balance):
    ''' float -> round.float -> string
takes balance and calculates the appropriate payment due.

Examples:
Credit card balance? 100
Minimum payment due: $12.0

Credit card balance? 501
Minimum payment due: $13.53'''
    # takes credit card balance and returns appropriate payment due
    if balance == 0:
        print ("Your balance is current, no payment is needed")
    elif 0 < balance <= 12:
        print ("Minimum payment due:","$" + str(round(balance, 2)))
    elif 12 <= balance <= 100:
        print ("Minimum payment due: $12.0")
    else:
        print ("Minimum payment due:", "$" + str(round((balance*.027), 2)))
        
reset = 'y'
while reset == 'y':
    account_balance = float(input("\nCredit card balance? "))
    get_minpay(account_balance)
    reset = input("\nAnother customer (y or n)? ")

# Tested with given values
#Tiny National Bank of Walterville
#Credit Card Payments
#
#Credit card balance? 100
#Minimum payment due: $12.0
#
#Another customer (y or n)? y
#
#Credit card balance? 501
#Minimum payment due: $13.53
#
#Another customer (y or n)? y
#
#Credit card balance? 8.97
#Minimum payment due: $8.97
#
#Another customer (y or n)? y
#
#Credit card balance? 0
#Your balance is current, no payment is needed
#
#Another customer (y or n)? n
