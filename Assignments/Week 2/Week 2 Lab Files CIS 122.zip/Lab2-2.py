# by Ian Garrett
# Lab2-2.py

def celsius_to_fahrenheit (celsius):
    # Convert degrees in celsius to degrees in fahrenheit
    fahrenheit = ((celsius*float(9/5))+32)
    return fahrenheit

print (celsius_to_fahrenheit(100))

f = celsius_to_fahrenheit(34)
print (f)

print (celsius_to_fahrenheit(-40.0))
    
