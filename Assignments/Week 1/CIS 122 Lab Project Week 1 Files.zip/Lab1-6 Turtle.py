# by Ian Garrett
import turtle
turtle.color ('purple')
# set proceeding turtle commands to print in purple ink
turtle.forward(100)
turtle.right(120)
#first of three lines that will form an equilateral triangle
turtle.forward(100)
turtle.right(120)
turtle.forward(100)
turtle.right(120)
