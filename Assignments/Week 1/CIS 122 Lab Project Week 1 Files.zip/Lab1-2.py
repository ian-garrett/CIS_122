# by Ian Garrett
message = "Hello World"
print (message)
