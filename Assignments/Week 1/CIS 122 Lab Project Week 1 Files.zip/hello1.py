# by Ian Garrett
Print ("Hello World!")
# Got a NameError "'Print' is not defined"
