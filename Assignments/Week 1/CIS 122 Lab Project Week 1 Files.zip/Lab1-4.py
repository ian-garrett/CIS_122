# by Ian Garrett
sales = 125000
stores = 4
total = sales * stores
# function to calculate a retail companies monthly profit
print (total)

sales = 200000
stores = 5
print (sales)
# new value replaced old value for "sales"

stores = 4
Stores = 23
print (stores)
print (Stores)
# results indicate that variables are case sensitive
