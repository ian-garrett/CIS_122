# by Ian Garrett
print ('Hello World')
# 'Hello World' was printed
