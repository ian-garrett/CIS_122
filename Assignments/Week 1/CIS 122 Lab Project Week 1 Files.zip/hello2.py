# by Ian Garrett
print "Hello World"
# "Invalid Syntex"
