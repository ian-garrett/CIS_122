# by Ian Garrett
sales = 125000
stores = 4
total = sales * stores
# function to calculate a retail companies monthly profit
print (total)
