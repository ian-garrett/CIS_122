# Ian Garrett
# Lab3-4

price = input("Enter the price: ")

print (round(float(price), 2))
