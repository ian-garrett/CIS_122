# Ian Garrett
# Lab3-1


phrase1 = "We'll be all right."
print (phrase1)

a = '"No way!"'
b = ' '
c = 'he said.'
phrase2 = (a + b + c)
print (phrase2)

phrase3 = "Chris said, \"It's OK\" and it was."
print (phrase3)

phrase4 = 'Use \\n for a "newline."'
print (phrase4)
