# Ian Garrett
# Lab3-3

age = 2
weight = 11.5

print ('The beagle is', age, 'years old')

print (weight, 'is the average weight.')

print (weight, "-", age,  "is", weight - age)
