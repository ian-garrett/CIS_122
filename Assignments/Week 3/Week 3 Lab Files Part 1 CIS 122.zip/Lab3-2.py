# Ian Garrett
# Lab3-2


stringa = '"*" + 20 * "-"'
print (stringa)
print (len(stringa))

stringb = '"WV\\nBMW"'
print (stringb)
print (len(stringb))

stringc = ''
print (stringc)
print (len(stringc))
